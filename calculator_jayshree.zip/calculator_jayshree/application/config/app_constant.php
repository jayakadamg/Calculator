<?php
defined('NPM_LIB_PATH') OR define('NPM_LIB_PATH','/node_modules/');