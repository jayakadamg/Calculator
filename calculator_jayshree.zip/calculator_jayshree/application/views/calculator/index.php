<!DOCTYPE html>
<html>

<head>
    <title>Calculator Project</title>
    <script>
        var base_url = '<?= base_url() ?>';
    </script>
    <script src="<?= base_url(NPM_LIB_PATH) ?>jquery/dist/jquery.min.js"></script>
    <script src="<?= base_url(NPM_LIB_PATH) ?>bootstrap/dist/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="<?= base_url(NPM_LIB_PATH) ?>bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?= base_url(NPM_LIB_PATH) ?>datatables/media/css/jquery.dataTables.min.css">
    <script src="<?= base_url(NPM_LIB_PATH) ?>datatables/media/js/jquery.dataTables.min.js"></script>
    <link rel="stylesheet" href="<?= base_url(); ?>assets/css/style.css">
</head>

<body>
    <div class="container">
        <h2>Calculator </h2>
        <p></p>
        <hr style="border: 1px solid;">
        <form id="calculatorForm">
            <table id="calculator">
                <tr>
                    <td>
                        <div class="alert alert-danger hide" role="alert" id="error">
                            <?php echo validation_errors();
                            if ($this->session->flashdata('error')) {
                                echo $this->session->flashdata('error');
                            }; ?>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td colspan="3">
                        <input type="text" id="calculatorInput" name="calculatorInput" value="" class="calc_text_input">
                    </td>
                </tr>
                <tr>
                    <td>
                        <input type="button" class="calc_buttton" value="AC" onclick="myApp.Calculator.clear_input()" onkeydown="myApp.Calculator.mergeValueToCalculate(event)">
                    </td>
                    <td>
                        <input type="button" class="calc_buttton" value="()" onclick="myApp.Calculator.addValueToCalculate('()')" onkeydown="myApp.Calculator.mergeValueToCalculate(event)">
                    </td>
                    <td>
                        <input type="button" class="calc_buttton" value="%" onclick="myApp.Calculator.addValueToCalculate('%')" onkeydown="myApp.Calculator.mergeValueToCalculate(event)">
                    </td>
                    <td>
                        <input type="button" class="calc_buttton" value="/" onclick="myApp.Calculator.addValueToCalculate('/')" onkeydown="myApp.Calculator.mergeValueToCalculate(event)">
                    </td>
                </tr>
                <tr>
                    <td>
                        <input type="button" class="calc_buttton" value="7" onclick="myApp.Calculator.addValueToCalculate('7')" onkeydown="myApp.Calculator.mergeValueToCalculate(event)">
                    </td>
                    <td>
                        <input type="button" class="calc_buttton" value="8" onclick="myApp.Calculator.addValueToCalculate('8')" onkeydown="myApp.Calculator.mergeValueToCalculate(event)">
                    </td>
                    <td>
                        <input type="button" class="calc_buttton" value="9" onclick="myApp.Calculator.addValueToCalculate('9')" onkeydown="myApp.Calculator.mergeValueToCalculate(event)">
                    </td>
                    <td>
                        <input type="button" class="calc_buttton" value="*" onclick="myApp.Calculator.addValueToCalculate('*')" onkeydown="myApp.Calculator.mergeValueToCalculate(event)">
                    </td>
                </tr>

                <tr>
                    <td>
                        <input type="button" class="calc_buttton" value="4" onclick="myApp.Calculator.addValueToCalculate('4')" onkeydown="myApp.Calculator.mergeValueToCalculate(event)">
                    </td>
                    <td>
                        <input type="button" class="calc_buttton" value="5" onclick="myApp.Calculator.addValueToCalculate('5')" onkeydown="myApp.Calculator.mergeValueToCalculate(event)">
                    </td>
                    <td>
                        <input type="button" class="calc_buttton" value="6" onclick="myApp.Calculator.addValueToCalculate('6')" onkeydown="myApp.Calculator.mergeValueToCalculate(event)">
                    </td>
                    <td>
                        <input type="button" class="calc_buttton" value="-" onclick="myApp.Calculator.addValueToCalculate('-')" onkeydown="myApp.Calculator.mergeValueToCalculate(event)">
                    </td>
                </tr>
                <tr>

                    <td>
                        <input type="button" class="calc_buttton" value="1" onclick="myApp.Calculator.addValueToCalculate('1')" onkeydown="myApp.Calculator.mergeValueToCalculate(event)">
                    </td>
                    <td>
                        <input type="button" class="calc_buttton" value="2" onclick="myApp.Calculator.addValueToCalculate('2')" onkeydown="myApp.Calculator.mergeValueToCalculate(event)">
                    </td>
                    <td>
                        <input type="button" class="calc_buttton" value="3" onclick="myApp.Calculator.addValueToCalculate('3')" onkeydown="myApp.Calculator.mergeValueToCalculate(event)">
                    </td>
                    <td>
                        <input type="button" class="calc_buttton" value="+" onclick="myApp.Calculator.addValueToCalculate('+')" onkeydown="myApp.Calculator.mergeValueToCalculate(event)">
                    </td>
                </tr>
                <tr>
                    <td>
                        <input type="button" class="calc_buttton" value="0" onclick="myApp.Calculator.addValueToCalculate('0')" onkeydown="myApp.Calculator.mergeValueToCalculate(event)">
                    </td>
                    <td>
                        <input type="button" class="calc_buttton" value="." onclick="myApp.Calculator.addValueToCalculate('.')" onkeydown="myApp.Calculator.mergeValueToCalculate(event)">
                    </td>
                    <td>
                        <input type="button" class="calc_buttton" value="clear" onclick="myApp.Calculator.clearfield()" onkeydown="myApp.Calculator.mergeValueToCalculate(event)">
                    </td>

                    <!-- calculate function call function calculate to evaluate value -->
                    <td>
                        <input type="submit" value="=" id="calculateAndSubmit" name="calculateAndSubmit" class="calc_buttton" title="Click to calculate and save">
                    </td>
                </tr>
            </table>
        </form>
        <hr style="border: 1px solid;">
        <h2>Latest Calculations</h2>
        <p></p>
        <table id="calculatorDataGrid" class="display" style="width:100%">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Expression</th>
                    <th>Result</th>
                    <th>Created at</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tfoot>
                <tr>
                    <th>ID</th>
                    <th>Expression</th>
                    <th>Result</th>
                    <th>Created at</th>
                    <th>Action</th>
                </tr>
            </tfoot>
        </table>
    </div>
    <script src="<?= base_url(NPM_LIB_PATH) ?>jquery-validation/dist/jquery.validate.min.js"></script>
    <script src="<?= base_url(); ?>assets/js/math.min.js"></script>
    <script src="<?= base_url(); ?>assets/js/calculator.js"></script>
</body>

</html>