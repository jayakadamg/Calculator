<?php

class Calculator_model extends CI_Model {
   
    /**
     * function name login
     * This function is used for user login
     * Created Date - 01-02-2020
     * */

    
    function getData() {  
       
        $this->db->select('tbl_calculator_operations_data.*');
        $this->db->from('tbl_calculator_operations_data');
        $this->db->where('tbl_calculator_operations_data.status', 1);
        $this->db->order_by("tbl_calculator_operations_data.id", "desc");
        $this->db->limit('5');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $data['cal_data'] = $query->result_array();
           
        } else {
            $data['cal_data'] = array();
        }

        
        return $data;

    }

    function save($data) {
        $user_id            = $this->session->userdata('loginUserId');
        $response           = ['error' => 1, 'message' => 'Unable to save data'];
        //print_r($data);exit;
        if(!empty($data)){
           // $save['input_expre_val']        =  $data['input_expre_val'];
            //$save['result_val']     =  $data['result_val'];
            $save['input_output_expre'] = json_encode($data);
            $save['status']         =  1;
            $save['created_at']     =  date('Y-m-d H:i:s');

            $res = $this->db->insert('tbl_calculator_operations_data', $save);
            $response           = ['error' => 0, 'message' => 'Data saved successfully !'];
            }
        

        return $response;
        
    }

    

}
