<?php

class Calculator_model extends CI_Model
{

    /**
     * function name getCalculationsData
     * This function is used to fetch calculations data
     * Created Date - 03-01-2023
     * */


    function getCalculationsData()
    {

        $this->db->select('tbl_calculator_operations_data.*');
        $this->db->from('tbl_calculator_operations_data');
        $this->db->where('tbl_calculator_operations_data.status', 1);
        $this->db->order_by("tbl_calculator_operations_data.id", "desc");
        $this->db->limit('5');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $data['cal_data'] = $query->result_array();
        } else {
            $data['cal_data'] = array();
        }


        return $data;
    }

    /**
     * function name save
     * This function is used to save calculations data
     * Created Date - 03-01-2023
     * */

    public function saveExpression($postData)
    {
        if (!empty($postData)) {
            $save['input_output_expre'] = json_encode($postData);
            $save['status']         =  1;
            $save['created_at']     =  date('Y-m-d H:i:s');

            try {
                $res = $this->db->insert('tbl_calculator_operations_data', $save);
                if ($res) {
                    $response = json_encode(['error' => 0, 'message' => 'Data saved successfully!']);
                }
            } catch (Exception $e) {
                $response = json_encode(['error' => 1, 'message' => $e->getMessage()]);
            }
        }
        return $response;
    }
    public function getExpressionList()
    {
        $expressionList = $this->db->select(
            'id,
            JSON_UNQUOTE(JSON_EXTRACT(input_output_expre, \'$.input_expre_val\')) as input_expre_val,
            JSON_UNQUOTE(JSON_EXTRACT(input_output_expre, \'$.result_val\')) as result_val,
            created_at'
        )
            ->from('tbl_calculator_operations_data tcod')
            ->where('tcod.status', 1)
            ->order_by("tcod.id", "desc")
            ->limit('5')
            ->get()
            ->result_array();
        //echo $this->db->last_query();
        //exit;
        $data = [
            "draw" => 1,
            "recordsFiltered" => count($expressionList),
            "recordsTotal" => count($expressionList),
            "data" => [],
        ];
        foreach ($expressionList as $row) {
            $data["data"][] = array_values($row);
        }
        return $data;
    }

    public function deleteExpression(int $rowId)
    {
        if ($rowId) :
            $this->db->trans_begin();
            $result = 0;
            $this->db->delete('tbl_calculator_operations_data', array('id' => $rowId));
            if ($this->db->trans_status() === false) {
                $this->db->trans_rollback();
                return false;
            } else {
                $this->db->trans_commit();
                return true;
            }

        endif;
        return 'No data found to delete!';
    }
}
