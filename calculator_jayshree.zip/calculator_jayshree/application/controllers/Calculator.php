<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Calculator extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->model('Calculator_model', 'Calculator');
        $this->load->library('form_validation');
    }

    /**
     * function name index
     * This function is used for calculator
     * Created Date - 03-01-2023
     * */
    public function index()
    {
        $this->load->view('calculator/index');
    }

    /**
     * function name index
     * This function is used for calculator input data
     * Created Date - 03-01-2023
     * */
    public function saveExpression()
    {
        if ($this->input->is_ajax_request() && $this->input->post()) {
            $rules = array(
                array(
                    'field' => 'input_expre_val',
                    'label' => 'Expression',
                    'rules' => 'required',
                    'errors' => array(
                        'required' => 'Please enter value to calculate.'
                    )
                )
            );
            $this->form_validation->set_rules($rules);

            if ($this->form_validation->run() == TRUE) {
                $postData = [
                    'input_expre_val' => $this->input->post('input_expre_val'),
                    'result_val' =>  $this->input->post('result_val'),
                ];
                $response = $this->Calculator->saveExpression($postData);
                echo $response;
                exit();
            }
        } else {
            //TODO :: must be render error page here.
            exit('Invalid Request!');
        }
    }

    public function getExpressionList()
    {
        if ($this->input->is_ajax_request()) {
            $gridData = $this->Calculator->getExpressionList();
            echo json_encode($gridData);
            exit;
        }
    }

    public function deleteExpression()
    {
        if ($this->input->is_ajax_request()) {
            $rowId = $this->input->post('rowId');
            if($this->Calculator->deleteExpression($rowId)){
                $response = ['status'=>"1",  'message' => "Recode deleted successfully."];
            }else{
                $response = ['status'=>"0",  'message' => "Error in recode delete."];
            }
            echo json_encode($response);
            exit;
        }
    }
}
