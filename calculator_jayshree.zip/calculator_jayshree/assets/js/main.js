function addValueToCalculate(val) {
    var inputBox = $('#calculatorInput').val();
    $('#calculatorInput').val(inputBox + val);
}

/**
 * function name clear_input
 * This function is used to clear one by one digit
 * Created Date - 03-01-2023
 * */
function clearfield() {
    var inputBox = $('#calculatorInput').val();
    var inputBox = inputBox.substring(0, inputBox.length - 1);
    $('#calculatorInput').val(inputBox);
}

function mergeValueToCalculate(event) {
    // if (event.key == '0' || event.key == '1' ||
    //     event.key == '2' || event.key == '3' ||
    //     event.key == '4' || event.key == '5' ||
    //     event.key == '6' || event.key == '7' ||
    //     event.key == '8' || event.key == '9' ||
    //     event.key == '+' || event.key == '-' ||
    //     event.key == '*' || event.key == '/') {
    //     var inputBox = $('#calculatorInput').val();
    //     $('#calculatorInput').val(inputBox + event.key);
    // } else {
    //     return false;
    // }

}
$('#calculator').on('keyup', function(event) {
    if (event.keyCode === 13) {
        console.log("Enter");
        var inputBox = $('#calculatorInput').val();
        console.log(inputBox);
        calculate();
    }
});

/**
 * function name calculate
 * This function is used to calculate math operation and save data in database 
 * Created Date - 03-01-2023
 * */

function calculate() {
    var input_expre_val = document.getElementById("calculatorInput").value
    var result_val = math.evaluate(input_expre_val)
    document.getElementById("calculatorInput").value = result_val
        /*
            $.ajax({
                type: "POST",
                dataType: "JSON",
                url: '<?php echo base_url(); ?>calculator/save',
                async: false,
                data: {
                    input_expre_val: input_expre_val,
                    result_val: result_val
                },
                success: function(response) {
                    console.log(response);

                }
            });*/
        // $('#cal').reset();
}

/**
 * function name clear_input
 * This function is used to clear input
 * Created Date - 03-01-2023
 * */

function clear_input() {
    $('#calculatorInput').val('');
}