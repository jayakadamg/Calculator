var myApp = myApp || {};

myApp.Calculator = {
    log_flag: true,
    dbSaveFlag: false,
    expGrid: '',
    expGridElement: $('#calculatorDataGrid'),
    app_log: function(key, value) {
        if (this.log_flag) {
            console.log(key, value);
        }
    },
    clearfield: function() {
        var inputBox = $('#calculatorInput').val();
        var inputBox = inputBox.substring(0, inputBox.length - 1);
        $('#calculatorInput').val(inputBox);
    },
    clear_input: function() {
        $('#calculatorInput').val('');
    },
    resetInputBox: function() {
        if (this.dbSaveFlag) {
            this.clear_input();
            this.dbSaveFlag = false;
        }
    },
    addValueToCalculate: function(val) {
        this.resetInputBox();
        var inputBox = $('#calculatorInput').val();
        $('#calculatorInput').val(inputBox + val);
    },
    mergeValueToCalculate: function(event) {
        this.resetInputBox();
        if (event.key == '0' || event.key == '1' ||
            event.key == '2' || event.key == '3' ||
            event.key == '4' || event.key == '5' ||
            event.key == '6' || event.key == '7' ||
            event.key == '8' || event.key == '9' ||
            event.key == '+' || event.key == '-' ||
            event.key == '*' || event.key == '/') {
            var inputBox = $('#calculatorInput').val();
            $('#calculatorInput').val(inputBox);
        }
    },
    saveExpression: function(calculateForm) {
        var input_expre_val = $('#calculatorInput').val();
        //calculate the expression
        var result_val = math.evaluate(input_expre_val)
        $("#calculatorInput").val(result_val);
        var $this = this;
        if (calculateForm.valid()) {
            $.ajax({
                type: "POST",
                dataType: "JSON",
                url: base_url + 'calculator/saveExpression',
                async: false,
                data: {
                    input_expre_val: input_expre_val,
                    result_val: result_val
                },
                success: function(response) {
                    $("#calculatorInput").val(result_val);
                    $this.dbSaveFlag = true;
                    $this.renderGrid();
                }
            });
        }
    },
    renderGrid: function() {

        if (this.expGrid == '') {
            this.expGrid = this.expGridElement.DataTable({
                processing: true,
                serverSide: true,
                type: "POST",
                dataType: "JSON",
                ajax: base_url + 'calculator/getExpressionList',
                columnDefs: [{
                    targets: -1,
                    data: null,
                    defaultContent: '<button class=\'btn btn-danger delete-grid-row\' >Delete</button>',
                }, ],
            });
            console.log('greate', this.expGrid);
        } else {
            this.expGrid.ajax.reload();
        }



    },
    deleteGridRow: function(rowId) {
        var $this = this;
        $.ajax({
            type: "POST",
            dataType: "JSON",
            url: base_url + 'calculator/deleteExpression',
            async: false,
            data: {
                rowId: rowId,
            },
            success: function(response) {
                //this.expGridElement.DataTable().ajax.reload();
                console.log('after delete', $this.expGrid);
                $this.expGrid.ajax.reload(null, false);
                alert(response.message);
            },
            failure: function(response) {
                alert(response.message);
            }
        });
    }
};

$(document).ready(function() {

    myApp.Calculator.renderGrid();

    $("#calculatorForm").validate({
        rules: {
            calculatorInput: "required"
        },
        messages: {
            calculatorInput: "Please value to calculate."
        },
        errorPlacement: function(error, element) {
            $('#error').addClass('show');
            error.appendTo($('#error'));
        },
        submitHandler: function(form) {
            if ($(form).valid()) {
                $('#error').addClass('hide').removeClass('show');
            } else {
                $('#error').addClass('show').removeClass('hide');
            }

            return false; // prevent normal form posting
        }
    });

    $('#calculatorForm').keyup(function(e) {
        myApp.Calculator.mergeValueToCalculate(e);
    });

    $('#calculatorForm').on('submit', function(e) {
        e.preventDefault();
        console.log('submitted.');
        myApp.Calculator.saveExpression($(this));
    });

    $('#calculatorDataGrid tbody').on('click', '.delete-grid-row', function() {
        var data = myApp.Calculator.expGrid.row($(this).parents('tr')).data();
        myApp.Calculator.deleteGridRow(data[0]);

    });
});